# Budget Consolidation reference

Customer-tunable settings for `budget-consolidation`. Settings here may tighten, but never loosen,
the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Budget cycle | [Budget Cycle] | e.g., FY27 annual budget or Q3 reforecast |
| Budget calendar | [Budget Calendar] | Submission deadlines, review dates, decision forums |
| Submission owners | [Submission Owners] | Owner of record per cost center, department, or entity |
| Submission location | [Submission Location] | SharePoint / OneDrive folder or list |
| Template | [Budget Template] | Required tabs, account mapping, validation rules |
| Targets | [Targets / Guidance] | Top-down targets, envelopes, planning assumptions |
| Comparatives | [Comparatives] | Prior-year actuals, current forecast, prior budget (Fabric / Power BI or workbook) |
| Decision forum | [Decision Forum] | Meeting, attendees, date |
| Packet audience | [Packet Audience] | Named recipients for draft budgets |
| Time zone | [Time Zone] | For deadlines and schedule |
| Schedule | Daily or twice-weekly sweep; weekly consolidation; packet before each forum | Budget season only |

## Rules and thresholds

| Rule | Default / placeholder | Notes |
| --- | --- | --- |
| Variance threshold | [Variance Thresholds] (example: >10% or >$250K vs. target or prior year) | Default from budget guidance |
| Status values | Received / Late / Missing / Resubmitted | Late = after deadline; Missing = not received |
| Days late | Today − due date (business days) | Formula in tracker |
| Validation checks | Required tabs/fields, mapping, totals tie to detail, driver logic | Add customer rules |
| Step-change flag | [Step-Change Rule] | Unexplained year-over-year jump per line |
| Chase cadence | Each sweep for Late / Missing units | Drafts only |

## KPI dictionary

| KPI | Definition | Source | Baseline field |
| --- | --- | --- | --- |
| Budget cycle time | Business days from calendar launch to approved budget | Budget calendar, approval record | Budget cycle time |
| Submission timeliness | Units submitted by deadline ÷ units required | Submission tracker | Submission timeliness |
| Variance issues caught before review | Issues flagged before forum ÷ total issues raised | Variance issues log, review notes | Variance issues caught before review |

## Output templates

| Artifact | Layout |
| --- | --- |
| Submission tracker (Excel) | Unit, Owner of Record, Due Date, Status, Received Date, Days Late (formula), Version, Validation Issues, Last Chase |
| Consolidation workbook (Excel) | Submissions; Roll-up (account, cost center, entity; formulas); Comparatives (Δ, Δ%); Exclusions |
| Variance issues log | Item, Unit, Δ vs. target/prior year, Threshold breached, Explanation and source, Owner, Status |
| Decision packet (Word or PowerPoint, 5-8 pages/slides) | Consolidated view; gap to target; top issues; options and tradeoffs; decisions; open items |
| Chaser email | Subject: [Budget Cycle] submission due <date>; body: what is outstanding, template link, open question |

## Connectors and fallbacks

| Source | Required / optional | If unavailable |
| --- | --- | --- |
| Fabric IQ / Power BI comparatives | Required for comparatives | Use provided workbook; state its date |
| ERP / planning system | Optional | Use provided hierarchy and mapping extract; state its date |
| Submission folder, mail, Teams | Required | Report status as a source gap |

## Never-automate list

- Sending chasers or clarification questions
- Booking the budget review or sending invites
- Sharing the decision packet
- Changing a submitted figure or loading or writing back budget data

## Sharing gate

Default state: not sent. Before any send or share, show exact recipients, content, attachments,
and a warning when draft budget, headcount, or compensation data is included.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits during budget season) |
| Intensity | Heavy |
| License-only starter | None defined |
| Credit band | Indicative per run: Light 100-300, Medium 300-700, Heavy 700+; actual use varies |

## Example prompt

> Run the budget consolidation for [Budget Cycle]. Check [Submission Location] and recent emails
> and Teams messages against [Submission Owners] and [Budget Calendar], and show which submissions
> are received, late, or missing. Draft reminders for anything outstanding. Validate each
> submission against [Budget Template], consolidate the valid inputs by account, cost center, and
> entity in an Excel workbook with formulas, and compare to [Targets / Guidance] and
> [Comparatives]. Flag every variance beyond [Variance Thresholds] with the owner's explanation or
> "Explanation required", and prepare a decision packet for [Decision Forum]. Hold all reminders,
> invites, and the packet for my approval. Save this process as a skill named [Budget
> Consolidation] so I can run it throughout budget season.
