# Close Owner Concierge reference

Customer-tunable routing for `close-owner-concierge`. Settings here may tighten, but never loosen,
the guardrails in `SKILL.md`.

## Customer settings

| Setting | Default / placeholder | Notes |
| --- | --- | --- |
| Plugin skills in scope | All six Close Owner skills | Remove skills not deployed |
| Sister concierge | `procurement-operator-concierge` | For procurement goals, if deployed |
| Expansion backlog | [Candidate Skill Backlog] | Where no-match goals are captured |
| Time zone | [Time Zone] | Used only when describing schedules |

## Routing table

| Goal / phrase | Skill | Trigger phrase | Schedule-worthy |
| --- | --- | --- | --- |
| Weekly leadership review, WBR, what changed since last review, stalled actions | `weekly-business-review` | "prep my weekly business review" | Yes - weekly before the review |
| Close package, flux commentary, explain variances, board close deck, close status | `close-and-variance-package` | "draft the close package for [Period]" | Yes - BD 2-3 status, BD 4-5 package |
| Budget submissions, chase inputs, consolidate budget, decision packet | `budget-consolidation` | "run the budget consolidation" | Yes - budget season only |
| Reconcile accounts, GL vs. bank, intercompany breaks, aged items | `reconciliation-review` | "reconcile [Account] for [Period]" | On demand or per close calendar |
| PBC list, audit requests, missing support, workpapers | `audit-evidence-package` | "build the audit pack for [Period]" | On demand; weekly in fieldwork |
| Market watch, competitor moves, market signals, Market Competition Analyzer | `market-intelligence` | "run my market watch" | Yes - Monday 8:00 AM PT |
| Routing help | `close-owner-concierge` | "help me choose" | On demand |

## Routing tests

| If the user says | Route to |
| --- | --- |
| "What changed since last week's review?" | `weekly-business-review` |
| "Write the flux commentary for P09" | `close-and-variance-package` |
| "Which budget submissions are still missing?" | `budget-consolidation` |
| "Find the breaks between the GL and the bank" | `reconciliation-review` |
| "What support are we missing for the audit?" | `audit-evidence-package` |
| "What did competitors do this week?" | `market-intelligence` |
| "Set up this new vendor" | `procurement-operator-concierge` |

## Ambiguity rules

- "Variance" with a period close or board -> close package; with budget, targets, or submissions -> budget consolidation; with week or plan -> weekly business review.
- "Review" with week, WBR, or leadership -> weekly business review; with reconciliation or breaks -> reconciliation review.
- "Regulatory" with news or market -> market intelligence; with a letter or agency request -> procurement concierge (regulatory-response).
- If two skills fit, pick the narrower artifact first and mention the alternative.

## Starter recommendation

Startup order (front door first): `close-owner-concierge`, `weekly-business-review`,
`close-and-variance-package`, `budget-consolidation`, `reconciliation-review`,
`audit-evidence-package`, `market-intelligence`. For "where do I start", recommend
`weekly-business-review` against a known-good dashboard.

## Schedule guidance

Schedule-worthy skills are marked above. Do not create a schedule; tell the user the sibling skill
can be scheduled after an on-demand run passes and they confirm the exact prompt, cadence, and time
zone.

## Never-automate list

- Running sibling-skill work (analysis, drafting, tie-outs)
- Creating or changing schedules
- Sending, posting, sharing, or filing anything

## Sharing gate

Default state: no action. The concierge produces only a routing recommendation; any share belongs
to the sibling skill's own sharing gate.

## Billing

| Item | Value |
| --- | --- |
| Model | UBB (Cowork on Copilot Credits) |
| Intensity | Light (routing only) |
| Credit band | Indicative per run: Light 100-300; actual use varies |

## Example prompt

> Help me choose: I need to get ready for [Period] close and the board meeting on [Date]. Which
> Close Owner skill should I start with, and what should I say to it?
